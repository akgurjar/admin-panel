
export * from './table.module';
